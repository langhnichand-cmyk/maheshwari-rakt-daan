package com.maheshwari.raktdaan;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.CookieManager;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.os.Build;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);

        // Keep the web app below Android's status/navigation bars on modern Android.
        // This prevents the header/menu/title from being drawn underneath the status bar.
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(185, 28, 28));
        if (Build.VERSION.SDK_INT >= 21) {
            window.setNavigationBarColor(Color.WHITE);
        }

        WebView w = new WebView(this);
        setContentView(w);
        w.setOnApplyWindowInsetsListener((view, insets) -> {
            int top = 0, bottom = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(0, top, 0, bottom);
            return insets;
        });
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        CookieManager.getInstance().setAcceptCookie(true);
        w.setWebViewClient(new WebViewClient());
        w.loadUrl("file:///android_asset/web/index.html");
    }
}
