-- Maheshwari Rakt Daan V28 Volunteer Accounts + Super Admin Access
-- Run this in Supabase SQL Editor.

ALTER TABLE public.volunteers ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.volunteers ADD COLUMN IF NOT EXISTS mobile text;
ALTER TABLE public.volunteers ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE public.volunteers ADD COLUMN IF NOT EXISTS city text;
ALTER TABLE public.volunteers ADD COLUMN IF NOT EXISTS area text;
ALTER TABLE public.volunteers ADD COLUMN IF NOT EXISTS reason text;
ALTER TABLE public.volunteers ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending';
ALTER TABLE public.volunteers ADD COLUMN IF NOT EXISTS approved boolean NOT NULL DEFAULT false;
ALTER TABLE public.volunteers ADD COLUMN IF NOT EXISTS created_at timestamptz DEFAULT now();

ALTER TABLE public.volunteers ENABLE ROW LEVEL SECURITY;
GRANT INSERT ON public.volunteers TO anon, authenticated;
GRANT SELECT, UPDATE ON public.volunteers TO authenticated;

DROP POLICY IF EXISTS "Anyone can apply as volunteer" ON public.volunteers;
CREATE POLICY "Anyone can apply as volunteer"
ON public.volunteers FOR INSERT TO anon, authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "Volunteers can view own application" ON public.volunteers;
CREATE POLICY "Volunteers can view own application"
ON public.volunteers FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "Volunteers can update own application" ON public.volunteers;
CREATE POLICY "Volunteers can update own application"
ON public.volunteers FOR UPDATE TO authenticated
USING (auth.uid() = user_id OR public.is_admin())
WITH CHECK (auth.uid() = user_id OR public.is_admin());

-- The admin is the super-admin: full database-table access through the app.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['donors','blood_requests','contact_requests','donation_history','notifications','volunteers'] LOOP
    EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON public.%I TO authenticated', t);
  END LOOP;
END $$;

-- Admin-only policies for volunteer management.
DROP POLICY IF EXISTS "Super admin manages volunteers" ON public.volunteers;
CREATE POLICY "Super admin manages volunteers"
ON public.volunteers FOR ALL TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());
