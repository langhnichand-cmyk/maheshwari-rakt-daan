V20 FIXED - DIRECT DONOR CONTACT

Important: Run SETUP_ALL_V20_V21.sql once in Supabase SQL Editor.
After that, every new donor registration made while logged in is automatically linked to that user's Supabase account.
A recipient contact request creates an in-app donor alert AND remains visible to admin.
No separate donor_direct_contact.sql is needed.

For testing: log in/register a normal account first, then register the donor. The donor row will receive user_id automatically.
