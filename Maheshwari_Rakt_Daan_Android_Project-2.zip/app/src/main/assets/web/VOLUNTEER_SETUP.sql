-- V28 Volunteer accounts + admin approval
CREATE TABLE IF NOT EXISTS public.volunteer_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  mobile text NOT NULL,
  email text NOT NULL,
  reason text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE public.volunteer_applications ENABLE ROW LEVEL SECURITY;
GRANT INSERT ON public.volunteer_applications TO anon, authenticated;
GRANT SELECT, UPDATE ON public.volunteer_applications TO authenticated;
DROP POLICY IF EXISTS "Volunteers can submit their own application" ON public.volunteer_applications;
CREATE POLICY "Volunteers can submit their own application"
ON public.volunteer_applications FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Applicants can view their own application" ON public.volunteer_applications;
CREATE POLICY "Applicants can view their own application"
ON public.volunteer_applications FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.is_admin());
DROP POLICY IF EXISTS "Admins can manage volunteer applications" ON public.volunteer_applications;
CREATE POLICY "Admins can manage volunteer applications"
ON public.volunteer_applications FOR UPDATE TO authenticated
USING (public.is_admin()) WITH CHECK (public.is_admin());
