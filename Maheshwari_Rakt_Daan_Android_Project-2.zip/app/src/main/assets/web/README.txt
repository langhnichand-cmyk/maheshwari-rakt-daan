MAHESHWARI RAKT DAAN — V27 DIRECT USER ACCESS

Normal users do NOT need to register or log in.
1. App opens with a simple Welcome screen.
2. Tap Enter App.
3. Users can directly Find Blood, Need Blood, or Donate Blood.
4. Donor and blood-request submissions are accepted without a user account.
5. Admin and approved volunteers use the separate Staff Login inside the side menu.

Normal-user OTP login has been removed from the app flow, so no SMS provider is required for public use.
