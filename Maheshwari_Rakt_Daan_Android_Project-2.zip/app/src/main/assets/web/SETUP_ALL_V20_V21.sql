-- MAHESHWARI RAKT DAAN - ONE-TIME DATABASE SETUP FOR V20/V21
-- Run this ONE script once in Supabase SQL Editor.
-- It combines donor account linking, direct donor alerts, recipient ownership,
-- and automatic donation-history creation.

-- 1) Ensure account-link columns exist.
ALTER TABLE public.donors
  ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.contact_requests
  ADD COLUMN IF NOT EXISTS requester_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_donors_user_id ON public.donors(user_id);
CREATE INDEX IF NOT EXISTS idx_contact_requests_requester_user_id ON public.contact_requests(requester_user_id);

-- 2) Automatically attach the currently logged-in user's auth ID to new donor registrations.
CREATE OR REPLACE FUNCTION public.set_donor_user_id_from_auth()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.user_id IS NULL THEN
    NEW.user_id := auth.uid();
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_set_donor_user_id_from_auth ON public.donors;
CREATE TRIGGER trg_set_donor_user_id_from_auth
BEFORE INSERT ON public.donors
FOR EACH ROW EXECUTE FUNCTION public.set_donor_user_id_from_auth();

-- 3) Direct donor contact alerts (recipient details are intentionally shared with selected donor).
CREATE TABLE IF NOT EXISTS public.donor_contact_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  donor_id uuid NOT NULL REFERENCES public.donors(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  contact_request_id uuid NOT NULL REFERENCES public.contact_requests(id) ON DELETE CASCADE,
  requester_name text NOT NULL,
  requester_mobile text NOT NULL,
  blood_group text NOT NULL,
  city text NOT NULL,
  message text,
  status text NOT NULL DEFAULT 'new',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.donor_contact_alerts ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.donor_contact_alerts TO authenticated;

DROP POLICY IF EXISTS "Donors can view their own contact alerts" ON public.donor_contact_alerts;
CREATE POLICY "Donors can view their own contact alerts"
ON public.donor_contact_alerts FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "Admins can manage donor contact alerts" ON public.donor_contact_alerts;
CREATE POLICY "Admins can manage donor contact alerts"
ON public.donor_contact_alerts FOR ALL TO authenticated
USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE OR REPLACE FUNCTION public.create_donor_contact_alert()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE d_user_id uuid;
BEGIN
  SELECT user_id INTO d_user_id FROM public.donors WHERE id = NEW.donor_id;
  IF d_user_id IS NOT NULL THEN
    INSERT INTO public.donor_contact_alerts
      (donor_id,user_id,contact_request_id,requester_name,requester_mobile,blood_group,city,message,status)
    VALUES
      (NEW.donor_id,d_user_id,NEW.id,NEW.requester_name,NEW.requester_mobile,NEW.blood_group,NEW.city,NEW.message,'new');
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_create_donor_contact_alert ON public.contact_requests;
CREATE TRIGGER trg_create_donor_contact_alert
AFTER INSERT ON public.contact_requests
FOR EACH ROW EXECUTE FUNCTION public.create_donor_contact_alert();

REVOKE INSERT, UPDATE, DELETE ON public.donor_contact_alerts FROM anon, authenticated;
GRANT SELECT ON public.donor_contact_alerts TO authenticated;

-- 4) Recipient can see/confirm only their own contact requests.
ALTER TABLE public.contact_requests ENABLE ROW LEVEL SECURITY;
GRANT SELECT, UPDATE ON public.contact_requests TO authenticated;

DROP POLICY IF EXISTS "Recipients can view their own contact requests" ON public.contact_requests;
CREATE POLICY "Recipients can view their own contact requests"
ON public.contact_requests FOR SELECT TO authenticated
USING (auth.uid() = requester_user_id OR public.is_admin());

DROP POLICY IF EXISTS "Recipients can confirm their own contact requests" ON public.contact_requests;
CREATE POLICY "Recipients can confirm their own contact requests"
ON public.contact_requests FOR UPDATE TO authenticated
USING (auth.uid() = requester_user_id OR public.is_admin())
WITH CHECK (auth.uid() = requester_user_id OR public.is_admin());

-- 5) Recipient confirmation automatically creates donor donation history once.
CREATE OR REPLACE FUNCTION public.confirm_blood_received(p_contact_request_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE r public.contact_requests%ROWTYPE; d_user_id uuid; existing_count integer;
BEGIN
  SELECT * INTO r FROM public.contact_requests
  WHERE id = p_contact_request_id AND requester_user_id = auth.uid();
  IF NOT FOUND THEN RAISE EXCEPTION 'Request not found or not owned by this recipient'; END IF;
  IF r.status = 'blood_received' THEN
    RETURN jsonb_build_object('ok',true,'already_confirmed',true);
  END IF;
  SELECT user_id INTO d_user_id FROM public.donors WHERE id = r.donor_id;
  IF d_user_id IS NULL THEN RAISE EXCEPTION 'Donor account is not linked'; END IF;
  SELECT count(*) INTO existing_count FROM public.donation_history
  WHERE donor_id = r.donor_id AND donation_date = current_date
    AND status = 'completed' AND COALESCE(hospital_name,'') = 'Recipient confirmed blood received';
  IF existing_count = 0 THEN
    INSERT INTO public.donation_history
      (donor_id,user_id,donation_date,hospital_name,units,status)
    VALUES
      (r.donor_id,d_user_id,current_date,'Recipient confirmed blood received',1,'completed');
  END IF;
  UPDATE public.contact_requests SET status='blood_received' WHERE id=r.id;
  UPDATE public.donor_contact_alerts SET status='blood_received' WHERE contact_request_id=r.id;
  RETURN jsonb_build_object('ok',true,'already_confirmed',false);
END;
$$;
GRANT EXECUTE ON FUNCTION public.confirm_blood_received(uuid) TO authenticated;

-- 6) Keep normal app permissions needed by V20/V21.
GRANT INSERT ON public.donors TO anon, authenticated;
GRANT SELECT, UPDATE ON public.donors TO authenticated;
GRANT INSERT ON public.contact_requests TO anon, authenticated;
GRANT SELECT, UPDATE ON public.contact_requests TO authenticated;
GRANT INSERT ON public.blood_requests TO anon, authenticated;
GRANT SELECT, UPDATE ON public.blood_requests TO authenticated;

-- NOTE: New donor registrations from the app are now automatically linked to auth.uid().
-- Existing donor rows created before this setup are not guessed/auto-matched because there is
-- no safe universal mapping from their mobile/name to an auth account.
