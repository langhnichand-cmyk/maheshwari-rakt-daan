-- MAHESHWARI RAKT DAAN - TEST DATA RESET
-- Run this ONCE in Supabase SQL Editor to remove test records.
-- This does NOT delete admin accounts, admin_roles, or database tables.

BEGIN;

-- Child/dependent records first
TRUNCATE TABLE
  public.contact_requests,
  public.donation_history,
  public.notifications,
  public.volunteers,
  public.blood_requests,
  public.donors
RESTART IDENTITY CASCADE;

-- If an emergency_alerts table exists from an earlier test version, clear it too.
DO $$
BEGIN
  IF to_regclass('public.emergency_alerts') IS NOT NULL THEN
    EXECUTE 'TRUNCATE TABLE public.emergency_alerts RESTART IDENTITY CASCADE';
  END IF;
END $$;

COMMIT;

-- Admin login/accounts and admin_roles are intentionally preserved.
